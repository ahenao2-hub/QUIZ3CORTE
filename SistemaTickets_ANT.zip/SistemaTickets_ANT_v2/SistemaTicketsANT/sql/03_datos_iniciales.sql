-- ============================================================
--  Script 3: Datos iniciales
-- ============================================================

-- Categorias
INSERT INTO CATEGORIAS (NOMBRE, DESCRIPCION) VALUES ('Red','Problemas de conectividad y red');
INSERT INTO CATEGORIAS (NOMBRE, DESCRIPCION) VALUES ('Hardware','Fallas en equipos fisicos');
INSERT INTO CATEGORIAS (NOMBRE, DESCRIPCION) VALUES ('Software','Errores en aplicaciones');
INSERT INTO CATEGORIAS (NOMBRE, DESCRIPCION) VALUES ('Acceso','Problemas de usuario o contrasena');
INSERT INTO CATEGORIAS (NOMBRE, DESCRIPCION) VALUES ('Otro','Solicitudes generales');

-- Admin (password: admin123)
INSERT INTO USUARIOS (NOMBRE, EMAIL, PASSWORD, ROL)
    VALUES ('Administrador','admin@tickets.com','admin123','ADMINISTRADOR');

-- Agente 1
INSERT INTO USUARIOS (NOMBRE, EMAIL, PASSWORD, ROL)
    VALUES ('Carlos Perez','carlos@tickets.com','agente123','AGENTE');
INSERT INTO AGENTES (ID_USUARIO, DEPARTAMENTO)
    VALUES ((SELECT ID_USUARIO FROM USUARIOS WHERE EMAIL='carlos@tickets.com'), 'Soporte Nivel 1');

-- Agente 2
INSERT INTO USUARIOS (NOMBRE, EMAIL, PASSWORD, ROL)
    VALUES ('Maria Lopez','maria@tickets.com','agente123','AGENTE');
INSERT INTO AGENTES (ID_USUARIO, DEPARTAMENTO)
    VALUES ((SELECT ID_USUARIO FROM USUARIOS WHERE EMAIL='maria@tickets.com'), 'Soporte Nivel 2');

-- Cliente de prueba
INSERT INTO USUARIOS (NOMBRE, EMAIL, PASSWORD, ROL)
    VALUES ('Juan Cliente','juan@cliente.com','cliente123','CLIENTE');
INSERT INTO CLIENTES (ID_USUARIO, TELEFONO)
    VALUES ((SELECT ID_USUARIO FROM USUARIOS WHERE EMAIL='juan@cliente.com'), '3001234567');

COMMIT;
