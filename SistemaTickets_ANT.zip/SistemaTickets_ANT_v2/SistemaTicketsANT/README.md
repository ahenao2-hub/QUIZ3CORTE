# Sistema de Tickets — Proyecto ANT para NetBeans
**Programación II | Java + Oracle XE**

---

## Cómo abrir en NetBeans

1. File → Open Project
2. Navegar hasta la carpeta **SistemaTickets** (la que tiene build.xml)
3. Clic en "Open Project" — NetBeans lo reconoce como Java Application ANT

---

## Agregar ojdbc8.jar (OBLIGATORIO antes de compilar)

1. Descargar ojdbc8.jar desde:
   https://www.oracle.com/database/technologies/appdev/jdbc-downloads.html
2. Copiar el archivo ojdbc8.jar dentro de la carpeta **lib/** del proyecto
3. En NetBeans: clic derecho sobre el proyecto → Properties → Libraries
   → Verify que aparece "ojdbc8.jar" en el classpath

---

## Configurar Oracle XE

Abrir SQL*Plus como SYSDBA:
```
sqlplus sys/TuPassword@xe as sysdba
```

Crear usuario:
```sql
CREATE USER TICKETS_USER IDENTIFIED BY tickets123;
GRANT CONNECT, RESOURCE, CREATE VIEW TO TICKETS_USER;
ALTER USER TICKETS_USER QUOTA UNLIMITED ON USERS;
EXIT;
```

Conectar como TICKETS_USER y ejecutar los 3 scripts:
```
sqlplus TICKETS_USER/tickets123@xe
@C:\ruta\sql\01_crear_tablas.sql
@C:\ruta\sql\02_crear_vistas.sql
@C:\ruta\sql\03_datos_iniciales.sql
EXIT;
```

---

## Verificar conexión

Abrir src/co/sistematickets/util/ConexionDB.java y confirmar:
```java
private static final String URL  = "jdbc:oracle:thin:@localhost:1521:xe";
private static final String USER = "TICKETS_USER";
private static final String PASS = "tickets123";
```

---

## Ejecutar

- Presionar **F6** en NetBeans, o
- Clic derecho sobre el proyecto → Run

---

## Usuarios de prueba

| Email                  | Contraseña  | Rol           |
|------------------------|-------------|---------------|
| admin@tickets.com      | admin123    | Administrador |
| carlos@tickets.com     | agente123   | Agente        |
| maria@tickets.com      | agente123   | Agente        |
| juan@cliente.com       | cliente123  | Cliente       |

---

## Estructura del proyecto ANT

```
SistemaTickets/
├── build.xml                  ← ANT build principal
├── manifest.mf                ← Manifiesto del JAR
├── nbproject/
│   ├── project.xml            ← Descriptor NetBeans
│   ├── project.properties     ← Propiedades (classpath, main class)
│   └── build-impl.xml         ← Implementación ANT
├── lib/
│   └── ojdbc8.jar             ← COLOCAR AQUI (descargar aparte)
├── src/
│   └── co/sistematickets/
│       ├── util/ConexionDB.java
│       ├── modelo/            Usuario, Ticket, Agente, Categoria
│       ├── dao/               TicketDAO, UsuarioDAO, ReporteDAO
│       ├── controlador/       TicketController, UsuarioController
│       └── vista/             LoginView, MainView, TicketPanel,
│                              ReportePanel
├── sql/
│   ├── 01_crear_tablas.sql
│   ├── 02_crear_vistas.sql
│   └── 03_datos_iniciales.sql
├── build/                     ← generado al compilar
└── dist/                      ← generado al compilar (contiene el JAR)
```
