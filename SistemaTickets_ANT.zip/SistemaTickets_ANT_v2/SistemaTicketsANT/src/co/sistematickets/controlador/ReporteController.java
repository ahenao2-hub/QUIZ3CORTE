package co.sistematickets.controlador;

import co.sistematickets.dao.ReporteDAO;
import java.util.List;
import java.util.Map;

public class ReporteController {

    private final ReporteDAO reporteDAO;

    public static final String[] VISTAS = {
        "VW_TICKETS_ACTIVOS",
        "VW_CARGA_AGENTES",
        "VW_TICKETS_POR_CATEGORIA",
        "VW_TIEMPOS_RESOLUCION",
        "VW_REPORTE_MENSUAL"
    };

    public ReporteController() {
        this.reporteDAO = new ReporteDAO();
    }

    public List<Map<String, Object>> ejecutar(String nombreVista) {
        return reporteDAO.ejecutarVista(nombreVista);
    }

    public String[] getColumnas(String nombreVista) {
        return reporteDAO.getColumnasVista(nombreVista);
    }
}
