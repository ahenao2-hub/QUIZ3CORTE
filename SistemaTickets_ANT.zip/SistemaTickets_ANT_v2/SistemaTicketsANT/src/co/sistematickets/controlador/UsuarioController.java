package co.sistematickets.controlador;

import co.sistematickets.dao.UsuarioDAO;
import co.sistematickets.modelo.Usuario;
import java.util.List;

public class UsuarioController {

    private final UsuarioDAO usuarioDAO;

    public UsuarioController() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public Usuario login(String email, String password) {
        if (email == null || password == null) return null;
        return usuarioDAO.login(email.trim(), password);
    }

    public boolean registrarCliente(String nombre, String email,
                                    String password, String telefono) {
        if (nombre.isBlank() || email.isBlank() || password.isBlank()) return false;
        return usuarioDAO.registrarCliente(nombre, email, password, telefono);
    }

    public int getIdCliente(int idUsuario) {
        return usuarioDAO.getIdClientePorUsuario(idUsuario);
    }

    public List<Usuario> listarUsuarios() {
        return usuarioDAO.listarUsuarios();
    }
}
