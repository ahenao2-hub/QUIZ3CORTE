package co.sistematickets.controlador;

import co.sistematickets.dao.TicketDAO;
import co.sistematickets.dao.UsuarioDAO;
import co.sistematickets.dao.AgenteDAO;
import co.sistematickets.dao.CategoriaDAO;
import co.sistematickets.modelo.*;
import java.util.List;

public class TicketController {

    private final TicketDAO    ticketDAO;
    private final AgenteDAO    agenteDAO;
    private final CategoriaDAO categoriaDAO;

    public TicketController() {
        this.ticketDAO    = new TicketDAO();
        this.agenteDAO    = new AgenteDAO();
        this.categoriaDAO = new CategoriaDAO();
    }

    public boolean crearTicket(String asunto, String descripcion,
                               String prioridad, int idCliente, int idCategoria) {
        if (asunto == null || asunto.trim().isEmpty()) return false;
        Ticket t = new Ticket(asunto.trim(), descripcion, prioridad, idCliente, idCategoria);
        return ticketDAO.insertar(t);
    }

    public List<Ticket> obtenerTodos()                  { return ticketDAO.listarTodos(); }
    public List<Ticket> obtenerPorEstado(String estado) { return ticketDAO.listarPorEstado(estado); }
    public Ticket       obtenerPorId(int id)            { return ticketDAO.buscarPorId(id); }

    public boolean asignarAgente(int idTicket, int idAgente) {
        return ticketDAO.asignarAgente(idTicket, idAgente);
    }

    public boolean resolverTicket(int idTicket, int idUsuario, String comentario) {
        boolean ok = ticketDAO.agregarComentario(idTicket, idUsuario, comentario);
        if (ok) ok = ticketDAO.cambiarEstado(idTicket, "RESUELTO");
        return ok;
    }

    public boolean cerrarTicket(int idTicket) {
        return ticketDAO.cambiarEstado(idTicket, "CERRADO");
    }

    public boolean cancelarTicket(int idTicket) {
        return ticketDAO.cambiarEstado(idTicket, "CANCELADO");
    }

    public List<Agente>    obtenerAgentes()    { return agenteDAO.listarAgentes(); }
    public List<Categoria> obtenerCategorias() { return categoriaDAO.listarCategorias(); }
}
