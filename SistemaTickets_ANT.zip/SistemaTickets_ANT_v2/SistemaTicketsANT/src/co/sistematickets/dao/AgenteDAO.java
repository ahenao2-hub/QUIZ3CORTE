package co.sistematickets.dao;

import co.sistematickets.modelo.Agente;
import co.sistematickets.util.ConexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgenteDAO {

    private Connection conn;

    public AgenteDAO() {
        this.conn = ConexionDB.getConexion();
    }

    public List<Agente> listarAgentes() {
        List<Agente> lista = new ArrayList<>();
        String sql = "SELECT ag.ID_AGENTE, ag.ID_USUARIO, u.NOMBRE, u.EMAIL, ag.DEPARTAMENTO " +
                     "FROM AGENTES ag JOIN USUARIOS u ON ag.ID_USUARIO = u.ID_USUARIO " +
                     "WHERE u.ACTIVO=1 ORDER BY u.NOMBRE";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Agente ag = new Agente(
                    rs.getInt   ("ID_AGENTE"),
                    rs.getInt   ("ID_USUARIO"),
                    rs.getString("NOMBRE"),
                    rs.getString("DEPARTAMENTO")
                );
                ag.setEmail(rs.getString("EMAIL"));
                lista.add(ag);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
