package co.sistematickets.dao;

import co.sistematickets.modelo.Categoria;
import co.sistematickets.util.ConexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    private Connection conn;

    public CategoriaDAO() {
        this.conn = ConexionDB.getConexion();
    }

    public List<Categoria> listarCategorias() {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT ID_CATEGORIA, NOMBRE FROM CATEGORIAS ORDER BY NOMBRE";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Categoria(
                    rs.getInt   ("ID_CATEGORIA"),
                    rs.getString("NOMBRE")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
