package co.sistematickets.dao;

import co.sistematickets.modelo.Ticket;
import co.sistematickets.util.ConexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketDAO {

    private Connection conn;

    public TicketDAO() {
        this.conn = ConexionDB.getConexion();
    }

    // ── INSERTAR ────────────────────────────────────────────
    public boolean insertar(Ticket t) {
        String sql = "INSERT INTO TICKETS (ASUNTO, DESCRIPCION, PRIORIDAD, ESTADO, " +
                     "ID_CLIENTE, ID_CATEGORIA) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getAsunto());
            ps.setString(2, t.getDescripcion());
            ps.setString(3, t.getPrioridad());
            ps.setString(4, "ABIERTO");
            ps.setInt   (5, t.getIdCliente());
            ps.setInt   (6, t.getIdCategoria());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ── LISTAR TODOS ────────────────────────────────────────
    public List<Ticket> listarTodos() {
        List<Ticket> lista = new ArrayList<>();
        String sql = "SELECT t.ID_TICKET, t.ASUNTO, t.PRIORIDAD, t.ESTADO, " +
                     "uc.NOMBRE AS CLIENTE, NVL(ua.NOMBRE,'Sin asignar') AS AGENTE, " +
                     "NVL(c.NOMBRE,'-') AS CATEGORIA, t.FECHA_CREACION " +
                     "FROM TICKETS t " +
                     "JOIN CLIENTES cl ON t.ID_CLIENTE = cl.ID_CLIENTE " +
                     "JOIN USUARIOS uc ON cl.ID_USUARIO = uc.ID_USUARIO " +
                     "LEFT JOIN AGENTES ag ON t.ID_AGENTE = ag.ID_AGENTE " +
                     "LEFT JOIN USUARIOS ua ON ag.ID_USUARIO = ua.ID_USUARIO " +
                     "LEFT JOIN CATEGORIAS c ON t.ID_CATEGORIA = c.ID_CATEGORIA " +
                     "ORDER BY t.FECHA_CREACION DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Ticket tk = new Ticket();
                tk.setIdTicket      (rs.getInt   ("ID_TICKET"));
                tk.setAsunto        (rs.getString("ASUNTO"));
                tk.setPrioridad     (rs.getString("PRIORIDAD"));
                tk.setEstado        (rs.getString("ESTADO"));
                tk.setNombreCliente (rs.getString("CLIENTE"));
                tk.setNombreAgente  (rs.getString("AGENTE"));
                tk.setNombreCategoria(rs.getString("CATEGORIA"));
                tk.setFechaCreacion (rs.getDate  ("FECHA_CREACION"));
                lista.add(tk);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ── LISTAR POR ESTADO ───────────────────────────────────
    public List<Ticket> listarPorEstado(String estado) {
        List<Ticket> lista = new ArrayList<>();
        String sql = "SELECT t.ID_TICKET, t.ASUNTO, t.PRIORIDAD, t.ESTADO, " +
                     "uc.NOMBRE AS CLIENTE, NVL(ua.NOMBRE,'Sin asignar') AS AGENTE, " +
                     "NVL(c.NOMBRE,'-') AS CATEGORIA, t.FECHA_CREACION " +
                     "FROM TICKETS t " +
                     "JOIN CLIENTES cl ON t.ID_CLIENTE = cl.ID_CLIENTE " +
                     "JOIN USUARIOS uc ON cl.ID_USUARIO = uc.ID_USUARIO " +
                     "LEFT JOIN AGENTES ag ON t.ID_AGENTE = ag.ID_AGENTE " +
                     "LEFT JOIN USUARIOS ua ON ag.ID_USUARIO = ua.ID_USUARIO " +
                     "LEFT JOIN CATEGORIAS c ON t.ID_CATEGORIA = c.ID_CATEGORIA " +
                     "WHERE t.ESTADO = ? ORDER BY t.FECHA_CREACION DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, estado);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Ticket tk = new Ticket();
                    tk.setIdTicket       (rs.getInt   ("ID_TICKET"));
                    tk.setAsunto         (rs.getString("ASUNTO"));
                    tk.setPrioridad      (rs.getString("PRIORIDAD"));
                    tk.setEstado         (rs.getString("ESTADO"));
                    tk.setNombreCliente  (rs.getString("CLIENTE"));
                    tk.setNombreAgente   (rs.getString("AGENTE"));
                    tk.setNombreCategoria(rs.getString("CATEGORIA"));
                    tk.setFechaCreacion  (rs.getDate  ("FECHA_CREACION"));
                    lista.add(tk);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ── ASIGNAR AGENTE ──────────────────────────────────────
    public boolean asignarAgente(int idTicket, int idAgente) {
        String sql = "UPDATE TICKETS SET ID_AGENTE=?, ESTADO='EN_PROGRESO' WHERE ID_TICKET=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idAgente);
            ps.setInt(2, idTicket);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ── CAMBIAR ESTADO ──────────────────────────────────────
    public boolean cambiarEstado(int idTicket, String nuevoEstado) {
        String sql;
        if (nuevoEstado.equals("CERRADO") || nuevoEstado.equals("RESUELTO")) {
            sql = "UPDATE TICKETS SET ESTADO=?, FECHA_CIERRE=SYSDATE WHERE ID_TICKET=?";
        } else {
            sql = "UPDATE TICKETS SET ESTADO=? WHERE ID_TICKET=?";
        }
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            ps.setInt   (2, idTicket);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ── AGREGAR COMENTARIO ──────────────────────────────────
    public boolean agregarComentario(int idTicket, int idUsuario, String texto) {
        String sql = "INSERT INTO COMENTARIOS (ID_TICKET, ID_USUARIO, TEXTO) VALUES (?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt   (1, idTicket);
            ps.setInt   (2, idUsuario);
            ps.setString(3, texto);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ── BUSCAR POR ID ───────────────────────────────────────
    public Ticket buscarPorId(int idTicket) {
        String sql = "SELECT t.*, uc.NOMBRE AS CLIENTE, NVL(ua.NOMBRE,'Sin asignar') AS AGENTE, " +
                     "NVL(c.NOMBRE,'-') AS CATEGORIA " +
                     "FROM TICKETS t " +
                     "JOIN CLIENTES cl ON t.ID_CLIENTE = cl.ID_CLIENTE " +
                     "JOIN USUARIOS uc ON cl.ID_USUARIO = uc.ID_USUARIO " +
                     "LEFT JOIN AGENTES ag ON t.ID_AGENTE = ag.ID_AGENTE " +
                     "LEFT JOIN USUARIOS ua ON ag.ID_USUARIO = ua.ID_USUARIO " +
                     "LEFT JOIN CATEGORIAS c ON t.ID_CATEGORIA = c.ID_CATEGORIA " +
                     "WHERE t.ID_TICKET = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idTicket);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Ticket tk = new Ticket();
                    tk.setIdTicket       (rs.getInt   ("ID_TICKET"));
                    tk.setAsunto         (rs.getString("ASUNTO"));
                    tk.setDescripcion    (rs.getString("DESCRIPCION"));
                    tk.setPrioridad      (rs.getString("PRIORIDAD"));
                    tk.setEstado         (rs.getString("ESTADO"));
                    tk.setIdCliente      (rs.getInt   ("ID_CLIENTE"));
                    tk.setNombreCliente  (rs.getString("CLIENTE"));
                    tk.setIdAgente       (rs.getInt   ("ID_AGENTE"));
                    tk.setNombreAgente   (rs.getString("AGENTE"));
                    tk.setNombreCategoria(rs.getString("CATEGORIA"));
                    tk.setFechaCreacion  (rs.getDate  ("FECHA_CREACION"));
                    tk.setFechaCierre    (rs.getDate  ("FECHA_CIERRE"));
                    return tk;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
