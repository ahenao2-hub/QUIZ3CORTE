package co.sistematickets.dao;

import co.sistematickets.modelo.Usuario;
import co.sistematickets.util.ConexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private Connection conn;

    public UsuarioDAO() {
        this.conn = ConexionDB.getConexion();
    }

    // LOGIN
    public Usuario login(String email, String password) {

        String sql =
            "SELECT ID_USUARIO, NOMBRE, EMAIL, ROL " +
            "FROM USUARIOS " +
            "WHERE EMAIL=? AND CLAVE=? AND ACTIVO=1";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    return new Usuario(
                        rs.getInt("ID_USUARIO"),
                        rs.getString("NOMBRE"),
                        rs.getString("EMAIL"),
                        rs.getString("ROL")
                    );
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // REGISTRAR CLIENTE
    public boolean registrarCliente(String nombre,
                                    String email,
                                    String password,
                                    String telefono) {

        String sqlU =
            "INSERT INTO USUARIOS " +
            "(ID_USUARIO,NOMBRE,EMAIL,CLAVE,ROL,ACTIVO) " +
            "VALUES (SEQ_USUARIOS.NEXTVAL,?,?,?,'CLIENTE',1)";

        String sqlC =
            "INSERT INTO CLIENTES " +
            "(ID_CLIENTE,ID_USUARIO,TELEFONO,FECHA_REGISTRO) " +
            "VALUES (" +
            "SEQ_CLIENTES.NEXTVAL," +
            "(SELECT ID_USUARIO FROM USUARIOS WHERE EMAIL=?)," +
            "?,SYSDATE)";

        try {

            conn.setAutoCommit(false);

            try (PreparedStatement ps1 = conn.prepareStatement(sqlU)) {

                ps1.setString(1, nombre);
                ps1.setString(2, email);
                ps1.setString(3, password);

                ps1.executeUpdate();
            }

            try (PreparedStatement ps2 = conn.prepareStatement(sqlC)) {

                ps2.setString(1, email);
                ps2.setString(2, telefono);

                ps2.executeUpdate();
            }

            conn.commit();
            conn.setAutoCommit(true);

            return true;

        } catch (SQLException e) {

            try {
                conn.rollback();
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // OBTENER ID CLIENTE
    public int getIdClientePorUsuario(int idUsuario) {

        String sql =
            "SELECT ID_CLIENTE " +
            "FROM CLIENTES " +
            "WHERE ID_USUARIO=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt("ID_CLIENTE");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    // LISTAR USUARIOS
    public List<Usuario> listarUsuarios() {

        List<Usuario> lista = new ArrayList<>();

        String sql =
            "SELECT ID_USUARIO, NOMBRE, EMAIL, ROL, ACTIVO " +
            "FROM USUARIOS " +
            "ORDER BY NOMBRE";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Usuario u = new Usuario(
                    rs.getInt("ID_USUARIO"),
                    rs.getString("NOMBRE"),
                    rs.getString("EMAIL"),
                    rs.getString("ROL")
                );

                u.setActivo(rs.getInt("ACTIVO") == 1);

                lista.add(u);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}