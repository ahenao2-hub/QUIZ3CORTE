package co.sistematickets.dao;

import co.sistematickets.util.ConexionDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Ejecuta las VIEWs de Oracle y devuelve los datos
 * como lista de mapas columna→valor para mostrar en JTable.
 */
public class ReporteDAO {

    private Connection conn;

    public ReporteDAO() {
        this.conn = ConexionDB.getConexion();
    }

    /**
     * Ejecuta cualquier VIEW por nombre y retorna filas como lista de mapas.
     * @param nombreVista  p.ej. "VW_TICKETS_ACTIVOS"
     * @return lista de filas; cada fila es mapa columna→valor
     */
    public List<Map<String, Object>> ejecutarVista(String nombreVista) {
        List<Map<String, Object>> filas = new ArrayList<>();
        String sql = "SELECT * FROM " + nombreVista;
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();
            while (rs.next()) {
                Map<String, Object> fila = new LinkedHashMap<>();
                for (int i = 1; i <= cols; i++) {
                    fila.put(meta.getColumnLabel(i), rs.getObject(i));
                }
                filas.add(fila);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return filas;
    }

    /**
     * Retorna los nombres de columna de una vista.
     */
    public String[] getColumnasVista(String nombreVista) {
        String sql = "SELECT * FROM " + nombreVista + " WHERE ROWNUM=0";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();
            String[] nombres = new String[cols];
            for (int i = 0; i < cols; i++) nombres[i] = meta.getColumnLabel(i + 1);
            return nombres;
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[]{};
        }
    }
}
