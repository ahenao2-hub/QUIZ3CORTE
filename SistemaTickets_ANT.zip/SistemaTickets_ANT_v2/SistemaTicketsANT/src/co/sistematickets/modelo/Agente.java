package co.sistematickets.modelo;

public class Agente {
    private int    idAgente;
    private int    idUsuario;
    private String nombre;
    private String email;
    private String departamento;

    public Agente() {}
    public Agente(int idAgente, int idUsuario, String nombre, String departamento) {
        this.idAgente     = idAgente;
        this.idUsuario    = idUsuario;
        this.nombre       = nombre;
        this.departamento = departamento;
    }

    public int    getIdAgente()              { return idAgente; }
    public void   setIdAgente(int id)        { this.idAgente = id; }
    public int    getIdUsuario()             { return idUsuario; }
    public void   setIdUsuario(int id)       { this.idUsuario = id; }
    public String getNombre()                { return nombre; }
    public void   setNombre(String n)        { this.nombre = n; }
    public String getEmail()                 { return email; }
    public void   setEmail(String e)         { this.email = e; }
    public String getDepartamento()          { return departamento; }
    public void   setDepartamento(String d)  { this.departamento = d; }

    @Override
    public String toString() { return nombre + " (" + departamento + ")"; }
}
