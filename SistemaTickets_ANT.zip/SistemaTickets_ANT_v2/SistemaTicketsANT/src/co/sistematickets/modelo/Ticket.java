package co.sistematickets.modelo;

import java.util.Date;

public class Ticket {
    private int    idTicket;
    private String asunto;
    private String descripcion;
    private String prioridad;    // BAJA | MEDIA | ALTA | CRITICA
    private String estado;       // ABIERTO | EN_PROGRESO | RESUELTO | CERRADO | CANCELADO
    private int    idCliente;
    private String nombreCliente;
    private int    idAgente;
    private String nombreAgente;
    private int    idCategoria;
    private String nombreCategoria;
    private Date   fechaCreacion;
    private Date   fechaCierre;

    public Ticket() {}

    // Constructor rapido para crear nuevo ticket
    public Ticket(String asunto, String descripcion, String prioridad,
                  int idCliente, int idCategoria) {
        this.asunto      = asunto;
        this.descripcion = descripcion;
        this.prioridad   = prioridad;
        this.estado      = "ABIERTO";
        this.idCliente   = idCliente;
        this.idCategoria = idCategoria;
    }

    // Getters y Setters
    public int    getIdTicket()                   { return idTicket; }
    public void   setIdTicket(int id)             { this.idTicket = id; }
    public String getAsunto()                     { return asunto; }
    public void   setAsunto(String a)             { this.asunto = a; }
    public String getDescripcion()                { return descripcion; }
    public void   setDescripcion(String d)        { this.descripcion = d; }
    public String getPrioridad()                  { return prioridad; }
    public void   setPrioridad(String p)          { this.prioridad = p; }
    public String getEstado()                     { return estado; }
    public void   setEstado(String e)             { this.estado = e; }
    public int    getIdCliente()                  { return idCliente; }
    public void   setIdCliente(int id)            { this.idCliente = id; }
    public String getNombreCliente()              { return nombreCliente; }
    public void   setNombreCliente(String n)      { this.nombreCliente = n; }
    public int    getIdAgente()                   { return idAgente; }
    public void   setIdAgente(int id)             { this.idAgente = id; }
    public String getNombreAgente()               { return nombreAgente; }
    public void   setNombreAgente(String n)       { this.nombreAgente = n; }
    public int    getIdCategoria()                { return idCategoria; }
    public void   setIdCategoria(int id)          { this.idCategoria = id; }
    public String getNombreCategoria()            { return nombreCategoria; }
    public void   setNombreCategoria(String n)    { this.nombreCategoria = n; }
    public Date   getFechaCreacion()              { return fechaCreacion; }
    public void   setFechaCreacion(Date f)        { this.fechaCreacion = f; }
    public Date   getFechaCierre()                { return fechaCierre; }
    public void   setFechaCierre(Date f)          { this.fechaCierre = f; }

    @Override
    public String toString() { return "#" + idTicket + " - " + asunto; }
}
