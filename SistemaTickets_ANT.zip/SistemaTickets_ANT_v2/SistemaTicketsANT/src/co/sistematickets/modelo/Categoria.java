package co.sistematickets.modelo;

public class Categoria {
    private int    idCategoria;
    private String nombre;
    private String descripcion;

    public Categoria() {}
    public Categoria(int id, String nombre) {
        this.idCategoria = id;
        this.nombre = nombre;
    }

    public int    getIdCategoria()           { return idCategoria; }
    public void   setIdCategoria(int id)     { this.idCategoria = id; }
    public String getNombre()                { return nombre; }
    public void   setNombre(String n)        { this.nombre = n; }
    public String getDescripcion()           { return descripcion; }
    public void   setDescripcion(String d)   { this.descripcion = d; }

    @Override
    public String toString() { return nombre; }
}
