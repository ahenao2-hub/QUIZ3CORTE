package co.sistematickets.modelo;

public class Usuario {
    private int    idUsuario;
    private String nombre;
    private String email;
    private String password;
    private String rol;   // CLIENTE | AGENTE | ADMINISTRADOR
    private boolean activo;

    public Usuario() {}

    public Usuario(int idUsuario, String nombre, String email, String rol) {
        this.idUsuario = idUsuario;
        this.nombre    = nombre;
        this.email     = email;
        this.rol       = rol;
        this.activo    = true;
    }

    // Getters y Setters
    public int     getIdUsuario()           { return idUsuario; }
    public void    setIdUsuario(int id)     { this.idUsuario = id; }
    public String  getNombre()              { return nombre; }
    public void    setNombre(String n)      { this.nombre = n; }
    public String  getEmail()               { return email; }
    public void    setEmail(String e)       { this.email = e; }
    public String  getPassword()            { return password; }
    public void    setPassword(String p)    { this.password = p; }
    public String  getRol()                 { return rol; }
    public void    setRol(String r)         { this.rol = r; }
    public boolean isActivo()               { return activo; }
    public void    setActivo(boolean a)     { this.activo = a; }

    @Override
    public String toString() { return nombre + " <" + email + ">"; }
}
