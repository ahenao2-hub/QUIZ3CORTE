package co.sistematickets.vista;

import co.sistematickets.controlador.UsuarioController;
import co.sistematickets.modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginView extends JFrame {

    private JTextField     txtEmail    = new JTextField(22);
    private JPasswordField txtPassword = new JPasswordField(22);
    private JButton        btnLogin    = new JButton("Ingresar");
    private JButton        btnRegistro = new JButton("Registrarse");
    private JLabel         lblMensaje  = new JLabel(" ");

    private final UsuarioController ctrl = new UsuarioController();

    public LoginView() {
        super("Sistema de Tickets — Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        construirUI();
        pack();
        setLocationRelativeTo(null);
    }

    private void construirUI() {
        // Panel principal
        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setBackground(new Color(30, 58, 90));

        // Cabecera
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER));
        header.setBackground(new Color(30, 58, 90));
        header.setBorder(BorderFactory.createEmptyBorder(28, 20, 10, 20));
        JLabel titulo = new JLabel("Sistema de Tickets");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);
        JLabel subtitulo = new JLabel("Soporte al Cliente");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitulo.setForeground(new Color(180, 210, 240));
        JPanel titulos = new JPanel();
        titulos.setLayout(new BoxLayout(titulos, BoxLayout.Y_AXIS));
        titulos.setOpaque(false);
        titulo.setAlignmentX(CENTER_ALIGNMENT);
        subtitulo.setAlignmentX(CENTER_ALIGNMENT);
        titulos.add(titulo);
        titulos.add(subtitulo);
        header.add(titulos);
        main.add(header, BorderLayout.NORTH);

        // Formulario
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 0, 6, 0);

        Font fLabel = new Font("Segoe UI", Font.PLAIN, 12);
        Font fField = new Font("Segoe UI", Font.PLAIN, 13);

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lEmail = new JLabel("Correo electrónico");
        lEmail.setFont(fLabel);
        form.add(lEmail, gbc);

        gbc.gridy = 1;
        txtEmail.setFont(fField);
        txtEmail.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        form.add(txtEmail, gbc);

        gbc.gridy = 2;
        JLabel lPass = new JLabel("Contraseña");
        lPass.setFont(fLabel);
        form.add(lPass, gbc);

        gbc.gridy = 3;
        txtPassword.setFont(fField);
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        form.add(txtPassword, gbc);

        gbc.gridy = 4;
        gbc.insets = new Insets(14, 0, 4, 0);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogin.setBackground(new Color(30, 95, 165));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setBorderPainted(false);
        btnLogin.setFocusPainted(false);
        btnLogin.setPreferredSize(new Dimension(0, 38));
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        form.add(btnLogin, gbc);

        gbc.gridy = 5;
        gbc.insets = new Insets(4, 0, 4, 0);
        btnRegistro.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRegistro.setBorderPainted(false);
        btnRegistro.setBackground(Color.WHITE);
        btnRegistro.setForeground(new Color(30, 95, 165));
        btnRegistro.setFocusPainted(false);
        btnRegistro.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        form.add(btnRegistro, gbc);

        gbc.gridy = 6;
        lblMensaje.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblMensaje.setForeground(new Color(180, 30, 30));
        lblMensaje.setHorizontalAlignment(SwingConstants.CENTER);
        form.add(lblMensaje, gbc);

        main.add(form, BorderLayout.CENTER);
        setContentPane(main);

        // Acciones
        btnLogin.addActionListener(e -> intentarLogin());
        txtPassword.addActionListener(e -> intentarLogin());

        btnRegistro.addActionListener(e -> {
            RegistroDialog dlg = new RegistroDialog(this, ctrl);
            dlg.setVisible(true);
        });
    }

    private void intentarLogin() {
        String email = txtEmail.getText().trim();
        String pass  = new String(txtPassword.getPassword());
        if (email.isEmpty() || pass.isEmpty()) {
            lblMensaje.setText("Complete todos los campos.");
            return;
        }
        Usuario u = ctrl.login(email, pass);
        if (u == null) {
            lblMensaje.setText("Credenciales incorrectas.");
            txtPassword.setText("");
        } else {
            lblMensaje.setText(" ");
            dispose();
            new MainView(u).setVisible(true);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new LoginView().setVisible(true));
    }
}
