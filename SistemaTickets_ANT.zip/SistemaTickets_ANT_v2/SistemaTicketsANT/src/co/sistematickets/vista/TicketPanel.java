package co.sistematickets.vista;

import co.sistematickets.controlador.TicketController;
import co.sistematickets.controlador.UsuarioController;
import co.sistematickets.modelo.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class TicketPanel extends JPanel {

    private final Usuario           usuarioActual;
    private final TicketController  ctrl      = new TicketController();
    private final UsuarioController userCtrl  = new UsuarioController();

    private DefaultTableModel modeloTabla;
    private JTable            tabla;
    private JComboBox<String> cmbFiltroEstado;
    private JLabel            lblEstado;

    private static final String[] COLUMNAS = {
        "ID", "Asunto", "Cliente", "Agente", "Categoría", "Prioridad", "Estado", "Fecha"
    };

    public TicketPanel(Usuario u) {
        this.usuarioActual = u;
        setLayout(new BorderLayout(0, 0));
        setBackground(MainView.GRIS_FONDO);
        construirUI();
        cargarTickets();
    }

    private void construirUI() {
        // ── Título ────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(MainView.BLANCO);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 10, 20));
        JLabel titulo = new JLabel("Gestión de Tickets");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(MainView.AZUL_OSCURO);
        header.add(titulo, BorderLayout.WEST);

        lblEstado = new JLabel(" ");
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblEstado.setForeground(new Color(80, 140, 80));
        header.add(lblEstado, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ── Barra de filtros y botones ───────────────────────
        JPanel barraFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        barraFiltros.setBackground(MainView.BLANCO);
        barraFiltros.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 225, 232)));

        barraFiltros.add(new JLabel("Filtrar por estado:"));
        cmbFiltroEstado = new JComboBox<>(new String[]{
            "TODOS","ABIERTO","EN_PROGRESO","RESUELTO","CERRADO","CANCELADO"
        });
        cmbFiltroEstado.addActionListener(e -> cargarTickets());
        barraFiltros.add(cmbFiltroEstado);

        barraFiltros.add(Box.createHorizontalStrut(20));

        JButton btnNuevo = boton("+ Nuevo ticket", new Color(30, 140, 70));
        btnNuevo.addActionListener(e -> abrirFormularioNuevo());
        barraFiltros.add(btnNuevo);

        if (!usuarioActual.getRol().equals("CLIENTE")) {
            JButton btnAsignar = boton("Asignar agente", new Color(30, 95, 165));
            btnAsignar.addActionListener(e -> asignarAgente());
            barraFiltros.add(btnAsignar);

            JButton btnResolver = boton("Resolver", new Color(140, 100, 20));
            btnResolver.addActionListener(e -> resolverTicket());
            barraFiltros.add(btnResolver);
        }

        JButton btnCerrar = boton("Cerrar ticket", new Color(160, 50, 50));
        btnCerrar.addActionListener(e -> cerrarTicket());
        barraFiltros.add(btnCerrar);

        JButton btnRefrescar = boton("↺ Refrescar", new Color(90, 90, 90));
        btnRefrescar.addActionListener(e -> cargarTickets());
        barraFiltros.add(btnRefrescar);

        add(barraFiltros, BorderLayout.NORTH);

        JPanel norte = new JPanel(new BorderLayout());
        norte.add(header, BorderLayout.NORTH);
        norte.add(barraFiltros, BorderLayout.SOUTH);
        add(norte, BorderLayout.NORTH);

        // ── Tabla ─────────────────────────────────────────────
        modeloTabla = new DefaultTableModel(COLUMNAS, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(28);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(44, 95, 138));
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.setSelectionBackground(new Color(210, 230, 255));
        tabla.setGridColor(new Color(230, 233, 238));
        tabla.setShowGrid(true);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Columna ID más estrecha
        tabla.getColumnModel().getColumn(0).setPreferredWidth(45);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(200);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(70);
        tabla.getColumnModel().getColumn(6).setPreferredWidth(90);

        // Colores por estado en columna "Estado"
        tabla.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {
    @Override
    public Component getTableCellRendererComponent(JTable t, Object val,
            boolean sel, boolean foc, int row, int col) {

        super.getTableCellRendererComponent(
                t, val, sel, foc, row, col);

        setHorizontalAlignment(CENTER);

        String estado =
                val == null ? "" : val.toString();

        if (!sel) {

            switch (estado) {

                case "ABIERTO":
                    setBackground(new Color(220, 245, 220));
                    break;

                case "EN_PROGRESO":
                    setBackground(new Color(255, 243, 200));
                    break;

                case "RESUELTO":
                    setBackground(new Color(200, 230, 255));
                    break;

                case "CERRADO":
                    setBackground(new Color(235, 235, 235));
                    break;

                case "CANCELADO":
                    setBackground(new Color(255, 220, 220));
                    break;

                default:
                    setBackground(Color.WHITE);
                    break;
            }
        }

        return this;
    }
});

        // Colores por prioridad en columna "Prioridad"
        tabla.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

    @Override
    public Component getTableCellRendererComponent(
            JTable t,
            Object val,
            boolean sel,
            boolean foc,
            int row,
            int col) {

        super.getTableCellRendererComponent(
                t, val, sel, foc, row, col);

        setHorizontalAlignment(CENTER);

        String p =
                val == null ? "" : val.toString();

        if (!sel) {

            Color colorPrioridad;

            switch (p) {

                case "CRITICA":
                    colorPrioridad =
                            new Color(180, 0, 0);
                    break;

                case "ALTA":
                    colorPrioridad =
                            new Color(180, 80, 0);
                    break;

                case "MEDIA":
                    colorPrioridad =
                            new Color(130, 100, 0);
                    break;

                default:
                    colorPrioridad =
                            new Color(60, 120, 60);
                    break;
            }

            setForeground(colorPrioridad);

            setFont(
                getFont().deriveFont(Font.BOLD)
            );
        }

        return this;
    }
});

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(8, 12, 12, 12));
        add(scroll, BorderLayout.CENTER);
    }

    // ── Cargar datos ──────────────────────────────────────────
    private void cargarTickets() {
        modeloTabla.setRowCount(0);
        String filtro = (String) cmbFiltroEstado.getSelectedItem();
        List<Ticket> tickets = filtro.equals("TODOS")
            ? ctrl.obtenerTodos()
            : ctrl.obtenerPorEstado(filtro);
        for (Ticket t : tickets) {
            modeloTabla.addRow(new Object[]{
                t.getIdTicket(),
                t.getAsunto(),
                t.getNombreCliente(),
                t.getNombreAgente(),
                t.getNombreCategoria(),
                t.getPrioridad(),
                t.getEstado(),
                t.getFechaCreacion()
            });
        }
        lblEstado.setText(tickets.size() + " ticket(s) encontrado(s)");
    }

    // ── Nuevo ticket ──────────────────────────────────────────
    private void abrirFormularioNuevo() {
        int idCliente = userCtrl.getIdCliente(usuarioActual.getIdUsuario());
        if (idCliente < 0 && !usuarioActual.getRol().equals("ADMINISTRADOR")) {
            JOptionPane.showMessageDialog(this,
                "No se encontró perfil de cliente para este usuario.");
            return;
        }
        NuevoTicketDialog dlg = new NuevoTicketDialog(
            SwingUtilities.getWindowAncestor(this), ctrl, idCliente > 0 ? idCliente : 1);
        dlg.setVisible(true);
        cargarTickets();
    }

    // ── Asignar agente ────────────────────────────────────────
    private void asignarAgente() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) { mostrarError("Seleccione un ticket."); return; }
        int idTicket = (int) modeloTabla.getValueAt(fila, 0);

        List<Agente> agentes = ctrl.obtenerAgentes();
        if (agentes.isEmpty()) { mostrarError("No hay agentes registrados."); return; }

        Agente sel = (Agente) JOptionPane.showInputDialog(
            this, "Seleccione el agente:", "Asignar agente",
            JOptionPane.PLAIN_MESSAGE, null,
            agentes.toArray(), agentes.get(0));
        if (sel == null) return;

        if (ctrl.asignarAgente(idTicket, sel.getIdAgente())) {
            lblEstado.setText("Ticket #" + idTicket + " asignado a " + sel.getNombre());
            cargarTickets();
        } else {
            mostrarError("No se pudo asignar el agente.");
        }
    }

    // ── Resolver ticket ───────────────────────────────────────
    private void resolverTicket() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) { mostrarError("Seleccione un ticket."); return; }
        int idTicket = (int) modeloTabla.getValueAt(fila, 0);

        String comentario = JOptionPane.showInputDialog(this,
            "Describa la solución aplicada:", "Resolver ticket #" + idTicket,
            JOptionPane.PLAIN_MESSAGE);
        if (comentario == null || comentario.isBlank()) return;

        if (ctrl.resolverTicket(idTicket, usuarioActual.getIdUsuario(), comentario)) {
            lblEstado.setText("Ticket #" + idTicket + " marcado como RESUELTO.");
            cargarTickets();
        } else {
            mostrarError("No se pudo resolver el ticket.");
        }
    }

    // ── Cerrar ticket ─────────────────────────────────────────
    private void cerrarTicket() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) { mostrarError("Seleccione un ticket."); return; }
        int idTicket = (int) modeloTabla.getValueAt(fila, 0);

        int conf = JOptionPane.showConfirmDialog(this,
            "¿Cerrar definitivamente el ticket #" + idTicket + "?",
            "Confirmar cierre", JOptionPane.YES_NO_OPTION);
        if (conf != JOptionPane.YES_OPTION) return;

        if (ctrl.cerrarTicket(idTicket)) {
            lblEstado.setText("Ticket #" + idTicket + " cerrado.");
            cargarTickets();
        } else {
            mostrarError("No se pudo cerrar el ticket.");
        }
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private JButton boton(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 11));
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(b.getPreferredSize().width + 10, 30));
        return b;
    }
}
