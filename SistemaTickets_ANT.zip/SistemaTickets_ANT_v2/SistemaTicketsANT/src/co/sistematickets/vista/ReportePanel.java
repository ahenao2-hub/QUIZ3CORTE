package co.sistematickets.vista;

import co.sistematickets.controlador.UsuarioController;
import co.sistematickets.dao.ReporteDAO;
import co.sistematickets.modelo.Usuario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Map;

// ════════════════════════════════════════════════════════════
//  ReportePanel — ejecuta VIEWs de Oracle y muestra resultados
// ════════════════════════════════════════════════════════════
public class ReportePanel extends JPanel {

    private final ReporteDAO      dao    = new ReporteDAO();
    private DefaultTableModel     modelo;
    private JTable                tabla;
    private JLabel                lblInfo;

    private static final String[] VISTAS = {
        "VW_TICKETS_ACTIVOS",
        "VW_CARGA_AGENTES",
        "VW_TICKETS_POR_CATEGORIA",
        "VW_TIEMPOS_RESOLUCION",
        "VW_REPORTE_MENSUAL"
    };

    public ReportePanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(MainView.GRIS_FONDO);
        construirUI();
    }

    private void construirUI() {
        // Cabecera
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(MainView.BLANCO);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 10, 20));
        JLabel titulo = new JLabel("Reportes del Sistema");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(MainView.AZUL_OSCURO);
        header.add(titulo, BorderLayout.WEST);

        // Selector de vista
        JPanel barraSelector = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        barraSelector.setBackground(MainView.BLANCO);
        barraSelector.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 225, 232)));

        barraSelector.add(new JLabel("Seleccione reporte:"));
        JComboBox<String> cmbVista = new JComboBox<>(VISTAS);
        cmbVista.setPreferredSize(new Dimension(280, 28));
        barraSelector.add(cmbVista);

        JButton btnEjecutar = new JButton("▶  Ejecutar");
        btnEjecutar.setBackground(new Color(30, 95, 165));
        btnEjecutar.setForeground(Color.WHITE);
        btnEjecutar.setBorderPainted(false);
        btnEjecutar.setFocusPainted(false);
        btnEjecutar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        barraSelector.add(btnEjecutar);

        lblInfo = new JLabel("  ");
        lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblInfo.setForeground(new Color(80, 140, 80));
        barraSelector.add(lblInfo);

        JPanel norte = new JPanel(new BorderLayout());
        norte.add(header, BorderLayout.NORTH);
        norte.add(barraSelector, BorderLayout.SOUTH);
        add(norte, BorderLayout.NORTH);

        // Tabla de resultados
        modelo = new DefaultTableModel();
        tabla  = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(44, 95, 138));
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.setSelectionBackground(new Color(210, 230, 255));
        tabla.setGridColor(new Color(230, 233, 238));
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(8, 12, 12, 12));
        add(scroll, BorderLayout.CENTER);

        // Acción
        btnEjecutar.addActionListener(e -> {
            String vista = (String) cmbVista.getSelectedItem();
            ejecutarVista(vista);
        });
    }

    private void ejecutarVista(String nombreVista) {
        modelo.setRowCount(0);
        modelo.setColumnCount(0);

        String[]            cols  = dao.getColumnasVista(nombreVista);
        List<Map<String, Object>> filas = dao.ejecutarVista(nombreVista);

        for (String col : cols) modelo.addColumn(col);
        for (Map<String, Object> fila : filas) {
            Object[] row = new Object[cols.length];
            int i = 0;
            for (Object val : fila.values()) row[i++] = val;
            modelo.addRow(row);
        }
        lblInfo.setText(filas.size() + " fila(s)  —  " + nombreVista);
    }
}
