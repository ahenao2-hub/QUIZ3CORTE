package co.sistematickets.vista;

import co.sistematickets.modelo.Usuario;
import javax.swing.*;
import java.awt.*;

public class MainView extends JFrame {

    private final Usuario usuarioActual;
    private JPanel        panelContenido;
    private JLabel        lblBienvenida;

    // Colores corporativos
    public static final Color AZUL_OSCURO  = new Color(30,  58,  90);
    public static final Color AZUL_MEDIO   = new Color(44,  95, 138);
    public static final Color BLANCO       = Color.WHITE;
    public static final Color GRIS_FONDO   = new Color(245, 247, 250);

    public MainView(Usuario u) {
        super("Sistema de Tickets — " + u.getNombre());
        this.usuarioActual = u;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1050, 680);
        setMinimumSize(new Dimension(900, 580));
        construirUI();
        setLocationRelativeTo(null);
        // Mostrar panel tickets al abrir
        mostrarPanel(new TicketPanel(usuarioActual));
    }

    private void construirUI() {
        setLayout(new BorderLayout());

        // ── Barra superior ───────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(AZUL_OSCURO);
        topBar.setPreferredSize(new Dimension(0, 52));
        topBar.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JLabel appTitulo = new JLabel("🎫  Sistema de Tickets y Soporte al Cliente");
        appTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        appTitulo.setForeground(BLANCO);
        topBar.add(appTitulo, BorderLayout.WEST);

        lblBienvenida = new JLabel(usuarioActual.getNombre() + "  [" + usuarioActual.getRol() + "]");
        lblBienvenida.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblBienvenida.setForeground(new Color(180, 210, 240));
        topBar.add(lblBienvenida, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // ── Menú lateral ─────────────────────────────────────
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(22, 44, 70));
        sidebar.setPreferredSize(new Dimension(190, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(16, 0, 16, 0));

        agregarBotonMenu(sidebar, "📋  Tickets",      () -> mostrarPanel(new TicketPanel(usuarioActual)));
        agregarBotonMenu(sidebar, "📊  Reportes",     () -> mostrarPanel(new ReportePanel()));
        if (usuarioActual.getRol().equals("ADMINISTRADOR")) {
            agregarBotonMenu(sidebar, "👥  Usuarios", () -> mostrarPanel(new UsuarioPanel()));
        }
        sidebar.add(Box.createVerticalGlue());
        agregarBotonMenu(sidebar, "🚪  Cerrar sesión", () -> {
            dispose();
            new LoginView().setVisible(true);
        });
        add(sidebar, BorderLayout.WEST);

        // ── Área de contenido ─────────────────────────────────
        panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBackground(GRIS_FONDO);
        add(panelContenido, BorderLayout.CENTER);
    }

    private void agregarBotonMenu(JPanel sidebar, String texto, Runnable accion) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(new Color(200, 225, 255));
        btn.setBackground(new Color(22, 44, 70));
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(44, 80, 120));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(22, 44, 70));
            }
        });
        btn.addActionListener(e -> accion.run());
        sidebar.add(btn);
    }

    public void mostrarPanel(JPanel panel) {
        panelContenido.removeAll();
        panelContenido.add(panel, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }
}
