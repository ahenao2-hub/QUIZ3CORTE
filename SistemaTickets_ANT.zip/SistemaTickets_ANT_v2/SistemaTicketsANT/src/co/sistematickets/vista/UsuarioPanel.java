package co.sistematickets.vista;

import co.sistematickets.controlador.UsuarioController;
import co.sistematickets.modelo.Usuario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UsuarioPanel extends JPanel {

    private final UsuarioController  ctrl  = new UsuarioController();
    private DefaultTableModel        modelo;

    private static final String[] COLUMNAS = {"ID", "Nombre", "Correo", "Rol", "Activo"};

    public UsuarioPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(MainView.GRIS_FONDO);
        construirUI();
        cargarUsuarios();
    }

    private void construirUI() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(MainView.BLANCO);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel titulo = new JLabel("Gestion de Usuarios");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(MainView.AZUL_OSCURO);
        header.add(titulo, BorderLayout.WEST);

        JButton btnRefrescar = new JButton("Refrescar");
        btnRefrescar.addActionListener(e -> cargarUsuarios());
        header.add(btnRefrescar, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        modelo = new DefaultTableModel(COLUMNAS, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabla = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(44, 95, 138));
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.setGridColor(new Color(230, 233, 238));

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(8, 12, 12, 12));
        add(scroll, BorderLayout.CENTER);
    }

    private void cargarUsuarios() {
        modelo.setRowCount(0);
        List<Usuario> lista = ctrl.listarUsuarios();
        for (Usuario u : lista) {
            modelo.addRow(new Object[]{
                u.getIdUsuario(), u.getNombre(), u.getEmail(),
                u.getRol(), u.isActivo() ? "Si" : "No"
            });
        }
    }
}
