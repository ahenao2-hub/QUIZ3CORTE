package co.sistematickets.vista;

import co.sistematickets.controlador.UsuarioController;
import javax.swing.*;
import java.awt.*;

public class RegistroDialog extends JDialog {

    private JTextField     txtNombre   = new JTextField(20);
    private JTextField     txtEmail    = new JTextField(20);
    private JPasswordField txtPass     = new JPasswordField(20);
    private JTextField     txtTel      = new JTextField(20);
    private JButton        btnGuardar  = new JButton("Registrarse");

    public RegistroDialog(JFrame parent, UsuarioController ctrl) {
        super(parent, "Registro de cliente", true);
        setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 10, 6, 10);
        g.fill   = GridBagConstraints.HORIZONTAL;

        String[] labels = {"Nombre completo:", "Correo:", "Contrasena:", "Telefono:"};
        JComponent[] fields = {txtNombre, txtEmail, txtPass, txtTel};
        for (int i = 0; i < labels.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0;
            add(new JLabel(labels[i]), g);
            g.gridx = 1; g.weightx = 1;
            add(fields[i], g);
        }
        g.gridx = 1; g.gridy = labels.length;
        add(btnGuardar, g);

        btnGuardar.addActionListener(e -> {
            boolean ok = ctrl.registrarCliente(
                txtNombre.getText(), txtEmail.getText(),
                new String(txtPass.getPassword()), txtTel.getText());
            if (ok) {
                JOptionPane.showMessageDialog(this, "Registro exitoso. Ya puede iniciar sesion.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar. El correo puede estar en uso.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        pack();
        setLocationRelativeTo(parent);
    }
}
