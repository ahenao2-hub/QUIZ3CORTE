package co.sistematickets.vista;

import co.sistematickets.controlador.TicketController;
import co.sistematickets.modelo.Categoria;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class NuevoTicketDialog extends JDialog {

    public NuevoTicketDialog(Window parent, TicketController ctrl, int idCliente) {
        super(parent, "Nuevo Ticket", ModalityType.APPLICATION_MODAL);
        setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 12, 8, 12);
        g.fill   = GridBagConstraints.HORIZONTAL;

        JTextField       txtAsunto = new JTextField(28);
        JTextArea        txtDesc   = new JTextArea(4, 28);
        JComboBox<String> cmbPrio  = new JComboBox<>(new String[]{"BAJA","MEDIA","ALTA","CRITICA"});
        cmbPrio.setSelectedItem("MEDIA");

        List<Categoria> cats = ctrl.obtenerCategorias();
        JComboBox<Categoria> cmbCat = new JComboBox<>(cats.toArray(new Categoria[0]));

        String[]      etiquetas = {"Asunto:", "Descripcion:", "Prioridad:", "Categoria:"};
        JComponent[]  campos    = {txtAsunto, new JScrollPane(txtDesc), cmbPrio, cmbCat};

        for (int i = 0; i < etiquetas.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0;
            add(new JLabel(etiquetas[i]), g);
            g.gridx = 1; g.weightx = 1;
            add(campos[i], g);
        }

        JButton btnGuardar = new JButton("Guardar ticket");
        btnGuardar.setBackground(new Color(30, 140, 70));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setBorderPainted(false);
        g.gridx = 1; g.gridy = etiquetas.length;
        add(btnGuardar, g);

        btnGuardar.addActionListener(e -> {
            String asunto = txtAsunto.getText().trim();
            if (asunto.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El asunto es obligatorio.");
                return;
            }
            Categoria cat = (Categoria) cmbCat.getSelectedItem();
            boolean ok = ctrl.crearTicket(
                asunto, txtDesc.getText(),
                (String) cmbPrio.getSelectedItem(),
                idCliente,
                cat != null ? cat.getIdCategoria() : 1
            );
            if (ok) {
                JOptionPane.showMessageDialog(this, "Ticket creado exitosamente.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar el ticket.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        pack();
        setLocationRelativeTo(parent);
    }
}
