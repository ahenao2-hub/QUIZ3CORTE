package co.sistematickets.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton que provee la conexion JDBC a Oracle XE.
 * Cambiar URL, USER y PASSWORD segun su configuracion local.
 */
public class ConexionDB {

    private static final String URL  = "jdbc:oracle:thin:@192.168.254.215:1521:orcl";
    private static final String USER = "Ticket";
    private static final String PASS = "Ticket";

    private static Connection instancia = null;

    private ConexionDB() {}

    public static Connection getConexion() {
        try {
            if (instancia == null || instancia.isClosed()) {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                instancia = DriverManager.getConnection(URL, USER, PASS);
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Driver Oracle no encontrado. Agrega ojdbc8.jar al classpath.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error al conectar con Oracle: " + e.getMessage());
            e.printStackTrace();
        }
        return instancia;
    }

    public static void cerrar() {
        try {
            if (instancia != null && !instancia.isClosed()) {
                instancia.close();
                instancia = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
